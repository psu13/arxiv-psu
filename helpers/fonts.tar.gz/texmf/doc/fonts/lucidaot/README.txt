This is the Lucida OpenType distribution from the TeX Users Group,
including OpenType math fonts.  Both the text and math fonts can be used
with any OpenType-aware application, including the LuaTeX and XeTeX
extensions of TeX.

If you downloaded the OpenType-only lucidaotdk.zip, all the files will
be at the top level of the zip.

If you downloaded the combined OpenType+Type1 lucidaot1-tex.zip file,
the distribution will be arranged in the subdirectories which TeX needs;
see INSTALL-TeX.txt.

The installation documentation is in these (plain text) files:
INSTALL-sys-unix.txt    - installing Lucida OpenType as system fonts on Unix.
INSTALL-sys-mac.txt     - installing as system fonts on MacOSX.
INSTALL-sys-windows.txt - installing as system fonts on Windows.
INSTALL-TeX.txt         - installing Lucida OpenType in your TeX setup
                            on any platform.

(Here, "Unix" means any Unix-like system other than MacOSX: GNU/Linux,
any BSD, Solaris, AIX, etc.)

The lucidaot.pdf document contains samples and information about the
OpenType features of the fonts.

These help files are available on the web at
http://tug.org/store/lucida/README-opentype/ as well as in the
distribution.

(If you are downloading the older lucidaot-tex.zip or lucidaot.zip
distributions, without the DK fonts, please ignore the references to them.)

If you have questions or problems regarding installation or use, please
email lucida@tug.org; this is an open and publicly archived list for
Lucida discussion.  You can search the archives and/or subscribe via
http://lists.tug.org/lucida (you don't need to subscribe to post).
Questions or problems related to ordering or licensing should go to
lucida-admin@tug.org.

The TUG Lucida home page is http://tug.org/lucida.
Happy typesetting!

--
Legal: the Lucida fonts are made available only under an end-user or
site license, which you agreed to when you ordered the fonts.  The
license text is available in the distribution files
lucida-license-*.txt, or online via http://tug.org/lucida.  (This small
documentation file itself may be freely used, modified and/or
distributed, however.)

The Lucida typeface family was designed by Charles Bigelow and Kris Holmes.  
(R) Lucida is a trademark of Bigelow & Holmes Inc.
registered in the U.S. Patent & Trademark Office and other
jurisdictions.

TUG gratefully acknowledges Charles Bigelow and Kris Holmes for being
willing to continue enhancing their magnum opus.  Also, Mojca Miklavec
and Hans Hagen for originally promulgating the Lucida OpenType project,
Michael Sharpe and Khaled Hosny for doing the technical work, and
additional volunteers for testing, suggestions, and advice: Taco
Hoekwater, Boguslaw Jackowski, Will Robertson, Ulrik Vieth, and Bruno
Voisin.
