In 2015, the usual Lucida distribution from TUG was changed to include
both the OpenType and Type 1 font sets.  (Type 1 continues to be
available on its own as well.)

There is no attempt to create a unified installation procedure covering
both formats (they are too different).  Please work with them separately.

For installation of the OpenType fonts, please see README.txt in the
distribution (doc/fonts/lucidaot/README.txt) or on the web in
http://tug.org/store/lucida/README-opentype/

For installation of the Type 1 fonts, please see README.TUG in the
distribution (source/fonts/lucidabr/README.TUG) or on the web at
http://tug.org/store/lucida/README-type1.txt.

(The plethora of names is historical and seems more troublesome than
helpful to change at this point.  Sorry for any confusion.)

If you have questions or problems regarding installation or use, please
email lucida@tug.org; this is an open and publicly archived list for
Lucida discussion.  You can search the archives and/or subscribe via
http://lists.tug.org/lucida (you don't need to subscribe to post).
Questions or problems related to ordering or licensing should go to
lucida-admin@tug.org.

The TUG Lucida home page is http://tug.org/lucida.
Happy typesetting!

--
Legal: the Lucida fonts are made available only under an end-user or
site license, which you agreed to when you ordered the fonts.  The
license text is available in the distribution files
lucida-license-*.txt, or online via http://tug.org/lucida.  (This small
documentation file itself may be freely used, modified and/or
distributed, however.)
