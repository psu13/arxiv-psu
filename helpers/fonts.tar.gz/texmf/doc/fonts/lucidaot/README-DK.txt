The Lucida DK OpenType fonts were created in 2015; they are derived from
Lucida Grande Mono and Lucida Console.  They are available on their own
to TUG members who might already have the other Lucida OpenType fonts
from TUG.  More info: http://tug.org/store/lucida/opentype-dk.html

Installing them is the same process as for the full Lucida OpenType
distribution.  To avoid duplication, the lucidaot-dkonly.zip file
contains only the DK .otf fonts and accompanying .fontspec files for
TeX.  Therefore, if you don't already have the documentation, please see
the information on the web: http://tug.org/store/lucida/README-opentype/

If you have questions or problems regarding installation or use, please
email lucida@tug.org; this is an open and publicly archived list for
Lucida discussion.  You can search the archives and/or subscribe via
http://lists.tug.org/lucida (you don't need to subscribe to post).
Questions or problems related to ordering or licensing should go to
lucida-admin@tug.org.

The TUG Lucida home page is http://tug.org/lucida.
Happy (monospaced) typesetting!

--
Legal: the Lucida fonts are made available only under an end-user or
site license, which you agreed to when you ordered the fonts.  The
license text is available in the distribution files
lucida-license-*.txt, or online via http://tug.org/lucida.  (This small
documentation file itself may be freely used, modified and/or
distributed, however.)

The Lucida typeface family was designed by Charles Bigelow and Kris Holmes.  
(R) Lucida is a trademark of Bigelow & Holmes Inc.
registered in the U.S. Patent & Trademark Office and other
jurisdictions.

TUG gratefully acknowledges Charles Bigelow and Kris Holmes for being
willing to continue enhancing their magnum opus, the Lucida OpenType
volunteers, and for the DK fonts, Donald E. Knuth for the idea/request.
